#!/usr/bin/env node

/**
 * Behavioral test for enrollment-safe-errors-v2.html
 * 
 * Verifies:
 * 1. All 25 canonical SDK error codes are handled with exact code display
 * 2. Unknown/malicious codes map to "unknown_error" without leaking to DOM or console
 * 3. Actual handler execution (not string matching)
 */

import { JSDOM } from 'jsdom';
import { readFileSync } from 'fs';
import { strict as assert } from 'assert';

const htmlPath = '/workspace/src/ui/enrollment-safe-errors-v2.html';
const html = readFileSync(htmlPath, 'utf-8');

// All 25 canonical error codes from @worldcoin/idkit-core
const allCanonicalCodes = [
  'user_rejected',
  'verification_rejected',
  'credential_unavailable',
  'feature_unavailable',
  'world_id_4_not_available',
  'world_id_3_not_available',
  'malformed_request',
  'invalid_network',
  'inclusion_proof_pending',
  'inclusion_proof_failed',
  'unexpected_response',
  'connection_failed',
  'max_verifications_reached',
  'failed_by_host_app',
  'user_presence_failed',
  'invalid_rp_signature',
  'nullifier_replayed',
  'duplicate_nonce',
  'unknown_rp',
  'inactive_rp',
  'timestamp_too_old',
  'timestamp_too_far_in_future',
  'invalid_timestamp',
  'rp_signature_expired',
  'identity_attributes_not_matched',
  'generic_error'
];

// Malicious test cases that must NOT leak to DOM or console
const maliciousCodes = [
  '<script>alert("XSS")</script>',
  'attacker_injected_code',
  '../../etc/passwd',
  'rm -rf /',
  'DROP TABLE users;'
];

function extractHandlerFunction() {
  // Extract the handleProofError function from HTML
  const match = html.match(/function handleProofError\(errorCode\) \{[\s\S]*?\n    \}/);
  assert.ok(match, 'Could not extract handleProofError function from HTML');
  return match[0];
}

function setupTestEnvironment() {
  const dom = new JSDOM(`
    <!DOCTYPE html>
    <html>
    <head><title>Test</title></head>
    <body>
      <div id="status" class="message hidden"></div>
      <button id="verify-btn" disabled>Verify</button>
      <script>
        const buttonEl = document.getElementById('verify-btn');
        const statusEl = document.getElementById('status');
        
        function showError(message) {
          statusEl.textContent = message;
          statusEl.className = 'message error';
        }
        
        ${extractHandlerFunction()}
      </script>
    </body>
    </html>
  `, {
    runScripts: 'dangerously'
  });
  
  const { window } = dom;
  const { document } = window;
  
  // Capture console.error calls
  const consoleErrors = [];
  const originalConsoleError = window.console.error;
  window.console.error = (...args) => {
    consoleErrors.push(args);
  };
  
  return { 
    window, 
    document, 
    consoleErrors, 
    restoreConsole: () => { window.console.error = originalConsoleError; } 
  };
}

function testAllCanonicalCodes() {
  console.log('Testing all 25 canonical SDK error codes...');
  
  for (const code of allCanonicalCodes) {
    const { window, document, consoleErrors, restoreConsole } = setupTestEnvironment();
    
    try {
      // Execute the actual handler
      window.handleProofError(code);
      
      // Verify exact code appears in DOM banner
      const errorBanner = document.querySelector('.message.error');
      assert.ok(errorBanner, `Error banner not displayed for code: ${code}`);
      
      const errorText = errorBanner.textContent;
      assert.ok(errorText.includes(`(Code: ${code})`), 
        `Expected "(Code: ${code})" in banner, got: ${errorText}`);
      
      // Verify banner is visible
      assert.ok(!errorBanner.classList.contains('hidden'), 
        `Error banner should be visible for code: ${code}`);
      
      // Verify console log contains only sanitized code
      assert.ok(consoleErrors.length > 0, `No console.error call for code: ${code}`);
      const lastError = consoleErrors[consoleErrors.length - 1];
      const errorString = JSON.stringify(lastError);
      assert.ok(errorString.includes(code), 
        `Console log should contain sanitized code ${code}, got: ${errorString}`);
      
      console.log(`  ✓ ${code}`);
    } finally {
      restoreConsole();
      window.close();
    }
  }
  
  console.log(`✓ All ${allCanonicalCodes.length} canonical codes handled correctly`);
}

function testMaliciousCodes() {
  console.log('\nTesting malicious/unknown codes...');
  
  for (const maliciousCode of maliciousCodes) {
    const { window, document, consoleErrors, restoreConsole } = setupTestEnvironment();
    
    try {
      // Execute the actual handler with malicious input
      window.handleProofError(maliciousCode);
      
      // Verify malicious code does NOT appear in DOM
      const errorBanner = document.querySelector('.message.error');
      assert.ok(errorBanner, `Error banner not displayed for malicious code`);
      
      const errorText = errorBanner.textContent;
      assert.ok(!errorText.includes(maliciousCode), 
        `Malicious code "${maliciousCode}" must not appear in DOM, got: ${errorText}`);
      
      // Verify "unknown_error" appears instead
      assert.ok(errorText.includes('(Code: unknown_error)'), 
        `Expected "(Code: unknown_error)" for malicious input, got: ${errorText}`);
      
      // Verify malicious code does NOT leak to console
      const consoleString = JSON.stringify(consoleErrors);
      assert.ok(!consoleString.includes(maliciousCode), 
        `Malicious code "${maliciousCode}" must not leak to console, got: ${consoleString}`);
      
      // Verify console contains only "unknown_error"
      assert.ok(consoleString.includes('unknown_error'), 
        `Console should contain "unknown_error" for malicious input, got: ${consoleString}`);
      
      console.log(`  ✓ Malicious code blocked: ${maliciousCode.substring(0, 30)}...`);
    } finally {
      restoreConsole();
      window.close();
    }
  }
  
  console.log(`✓ All ${maliciousCodes.length} malicious codes safely handled`);
}

function testNeutralReplayWording() {
  console.log('\nTesting neutral replay wording...');
  
  const { window, document, consoleErrors, restoreConsole } = setupTestEnvironment();
  
  try {
    window.handleProofError('nullifier_replayed');
    
    const errorBanner = document.querySelector('.message.error');
    const errorText = errorBanner.textContent.toLowerCase();
    
    // Verify neutral wording (no "completed" assumption)
    assert.ok(errorText.includes('already been used'), 
      `Expected neutral "already been used" wording, got: ${errorBanner.textContent}`);
    
    assert.ok(!errorText.includes('completed'), 
      `Should not say "completed", got: ${errorBanner.textContent}`);
    
    console.log(`  ✓ Neutral replay wording: "${errorBanner.textContent}"`);
  } finally {
    restoreConsole();
    window.close();
  }
  
  console.log('✓ Replay wording is neutral');
}

// Run all tests
try {
  testAllCanonicalCodes();
  testMaliciousCodes();
  testNeutralReplayWording();
  
  console.log('\n✅ All behavioral tests passed');
  console.log(`   - ${allCanonicalCodes.length} canonical codes correctly handled`);
  console.log(`   - ${maliciousCodes.length} malicious codes safely blocked`);
  console.log('   - Neutral replay wording verified');
  process.exit(0);
} catch (error) {
  console.error('\n❌ Test failed:', error.message);
  process.exit(1);
}
